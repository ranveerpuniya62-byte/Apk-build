package com.techarenastudio.candyblast

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var consent: ConsentManager
    private lateinit var ads: AdBridge
    private lateinit var bannerHost: FrameLayout

    // System-bar / cutout insets (px) and the last safe-area values pushed into the page.
    private var systemInsets: Insets = Insets.NONE
    private var lastSafeAreaJs: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        // Let the game draw into the notch/cutout strip and under a transparent gesture/3-button bar
        // (no grey scrim) so there are no empty bands; insets are still passed to the page below.
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
        }

        // Same colour as the page boot background / splash video lead-in, so the system start
        // window, the empty WebView and the page itself look identical (no colour flashes).
        val bg = Color.parseColor("#050B1E")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        webView = WebView(this).apply {
            setBackgroundColor(bg)
            overScrollMode = View.OVER_SCROLL_NEVER
            isLongClickable = false
            setOnLongClickListener { true }
        }
        bannerHost = FrameLayout(this).apply { visibility = View.GONE }
        root.addView(webView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bannerHost, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        // The WebView now fills the whole screen (under status bar / notch / nav bar). Instead of
        // padding the root (which left empty bands) the insets go to the page as CSS variables
        // (--safe-top / --safe-bottom) used by the game's existing safe-area layout.
        // The banner host takes the nav-bar inset itself, so the banner always sits above the nav bar.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            systemInsets = b
            v.setPadding(b.left, 0, b.right, 0)
            bannerHost.setPadding(0, 0, 0, b.bottom)
            publishSafeArea(false)
            insets
        }
        // Banner show/hide (done by AdBridge) changes who clears the nav bar: re-publish on layout.
        bannerHost.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> publishSafeArea(false) }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // game progress is saved in localStorage
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
        }
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        // Order matters: ads need consent, consent calls back into ads.
        lateinit var adsRef: AdBridge
        consent = ConsentManager(this) { runOnUiThread { adsRef.onConsentChanged() } }
        ads = AdBridge(this, webView, bannerHost, consent)
        adsRef = ads

        webView.addJavascriptInterface(consent, "AndroidConsent")
        webView.addJavascriptInterface(ads.rewardedInterface, "AndroidRewardedAd")
        webView.addJavascriptInterface(ads.bannerInterface, "AndroidBanner")

        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/app/", GameHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            // Keep the player inside the game: ignore any outside navigation.
            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean = request.url.host != "appassets.androidplatform.net"

            // A new document starts without CSS variables: push the safe-area values again.
            override fun onPageCommitVisible(view: WebView, url: String) { publishSafeArea(true) }
            override fun onPageFinished(view: WebView, url: String) { publishSafeArea(true) }
        }

        // No default video poster: without this the WebView paints its grey "play button" picture
        // (stretched) over the splash video while it loads. Use a 1x1 page-colour bitmap instead.
        webView.webChromeClient = object : WebChromeClient() {
            override fun getDefaultVideoPoster(): Bitmap? {
                val b = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
                b.eraseColor(bg)
                return b
            }
        }

        webView.loadUrl("https://appassets.androidplatform.net/app/index.html")
        consent.start()
    }

    /** Sends the top/bottom safe-area (CSS px = dp) to the page; no-op if nothing changed. */
    private fun publishSafeArea(force: Boolean) {
        if (!::webView.isInitialized) return
        val d = resources.displayMetrics.density
        val top = systemInsets.top / d
        // While the banner is visible it already clears the nav bar, so the page needs no bottom inset.
        val bottom = if (bannerHost.visibility == View.VISIBLE) 0f else systemInsets.bottom / d
        val js = "(function(){var s=document.documentElement.style;" +
            "s.setProperty('--safe-top','" + top + "px');" +
            "s.setProperty('--safe-bottom','" + bottom + "px');" +
            "s.setProperty('--safe-left','0px');" +
            "s.setProperty('--safe-right','0px');})();"
        if (!force && js == lastSafeAreaJs) return
        lastSafeAreaJs = js
        webView.evaluateJavascript(js, null)
    }

    override fun onPause() { super.onPause(); webView.onPause(); ads.onPause() }
    override fun onResume() { super.onResume(); webView.onResume(); ads.onResume() }
    override fun onDestroy() {
        ads.onDestroy()
        (webView.parent as? android.view.ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }
}

/**
 * Serves assets/index.html. In DEBUG builds it switches the game's ad environment to 'test'
 * (Google sample ads), so you can never tap your own real ads while developing.
 * RELEASE builds serve the file unchanged ('production' ads).
 */
private class GameHandler(private val ctx: Context) : WebViewAssetLoader.PathHandler {
    override fun handle(path: String): WebResourceResponse? {
        if (path != "index.html") return null
        if (!BuildConfig.DEBUG) {
            // RELEASE: stream the asset straight through (no multi-MB String copy / re-encode),
            // so the page and the developer splash start as fast as possible.
            return WebResourceResponse("text/html", "UTF-8", ctx.assets.open("index.html"))
        }
        var html = ctx.assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
        if (BuildConfig.DEBUG) {
            html = html.replace(Regex("environment:\\s*'production',"), "environment: 'test',")
        }
        return WebResourceResponse("text/html", "UTF-8", ByteArrayInputStream(html.toByteArray(Charsets.UTF_8)))
    }
}
